# tic-tac-toe.ionic
Tic-Tac-Toe, implemented as an Ionic mobile application.
